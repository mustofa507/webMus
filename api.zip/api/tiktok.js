import fetch from 'node-fetch';

export default async function handler(req, res){
    const { url, type } = req.query;
    if(!url) return res.status(400).json({ success:false, message:"URL kosong!" });

    try {
        const apiRes = await fetch(`https://tikwm.com/api?url=${encodeURIComponent(url)}&hd=${type==='hd'?1:0}`);
        const data = await apiRes.json();
        if(data.code !== 0) return res.json({ success:false, message:data.message || "API gagal" });

        let link;
        if(type==='music') link = data.data.audio[0]?.url || '';
        else if(type==='hd') link = data.data.play[0]?.url || data.data.play[0]?.url;
        else link = data.data.play[0]?.url;

        res.json({ success:true, link });
    } catch(err){
        res.json({ success:false, message:err.message });
    }
}